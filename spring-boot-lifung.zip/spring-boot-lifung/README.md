# How to build project
-Step 1: Download maven, jdk and setup environment for the project base on java platform

-Step 2: Build project by commandline:   mvn clean install

-Step 3: Run project by commandline:     mvn spring-boot:run

# How to connect DB MySQL
-Need to create schema, username and password as application.properties file

    Example: schema: test, username: root, password: ChildHood
         